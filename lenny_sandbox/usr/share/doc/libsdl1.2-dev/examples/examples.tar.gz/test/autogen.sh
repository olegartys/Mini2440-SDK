#!/bin/sh
#
# Regenerate configuration files
aclocal-1.9
autoconf
