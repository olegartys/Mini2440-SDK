/* autoconf type defines can come here */
