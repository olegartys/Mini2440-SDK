#define SOLID
#include "triangl.c"

