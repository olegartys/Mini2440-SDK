#define INTERP
#include "triangl.c"

