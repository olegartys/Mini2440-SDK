#define WRAP
#define INTERP
#include "triangl.c"
