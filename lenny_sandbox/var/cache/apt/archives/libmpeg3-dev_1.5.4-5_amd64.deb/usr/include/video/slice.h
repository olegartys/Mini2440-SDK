#ifndef SLICE_H
#define SLICE_H

#include <sys/types.h>
#include <pthread.h>


#endif
