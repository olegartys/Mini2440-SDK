#ifndef _IP6T_RATE_H
#define _IP6T_RATE_H

#include <linux/netfilter/xt_limit.h>
#define IP6T_LIMIT_SCALE XT_LIMIT_SCALE
#define ip6t_rateinfo xt_rateinfo

#endif /*_IP6T_RATE_H*/
