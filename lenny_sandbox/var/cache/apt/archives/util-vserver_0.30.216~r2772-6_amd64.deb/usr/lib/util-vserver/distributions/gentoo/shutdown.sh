# Copyright 1999-2006 Gentoo Foundation
# Distributed under the terms of the GNU General Public License v2

# gentoo init style needs this (and nothing else)
exit 0
